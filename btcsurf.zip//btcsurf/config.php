<?

$btcsurfsession = "xxxxxxxxxx";
$xsrftoken = "xxxxxxxxxx";